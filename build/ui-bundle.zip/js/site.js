(()=>{var c,o,r,s=/^sect(\d)$/,i=document.querySelector(".nav-container"),e=document.querySelector(".theme-toggle"),a=document.querySelector(".navbar-burger"),l=(a.addEventListener("click",function(e){if(a.classList.contains("is-active"))return u(e);v(e);var e=document.documentElement,t=(e.classList.add("is-clipped--nav"),a.classList.add("is-active"),i.classList.add("is-active"),c.getBoundingClientRect()),n=window.innerHeight-Math.round(t.top);Math.round(t.height)!==n&&(c.style.height=n+"px");e.addEventListener("click",u)}),i.addEventListener("click",v),e.addEventListener("click",v),i.querySelector("[data-panel=menu]"));function t(){var e,t,n=window.location.hash;if(n&&(n.indexOf("%")&&(n=decodeURIComponent(n)),!(e=l.querySelector('.nav-link[href="'+n+'"]')))){n=document.getElementById(n.slice(1));if(n)for(var i=n,a=document.querySelector("article.doc");(i=i.parentNode)&&i!==a;){var c=i.id;if((c=c||(c=s.test(i.className))&&(i.firstElementChild||{}).id)&&(e=l.querySelector('.nav-link[href="#'+c+'"]')))break}}if(e)t=e.parentNode;else{if(!r)return;e=(t=r).querySelector(".nav-link")}t!==o&&(m(l,".nav-item.is-active").forEach(function(e){e.classList.remove("is-active","is-current-path","is-current-page")}),t.classList.add("is-current-page"),d(o=t),p(l,e))}function d(e){for(var t,n=e.parentNode;!(t=n.classList).contains("nav-menu");)"LI"===n.tagName&&t.contains("nav-item")&&t.add("is-active","is-current-path"),n=n.parentNode;e.classList.add("is-active")}function n(){var e,t,n,i;this.classList.toggle("is-active")&&(e=parseFloat(window.getComputedStyle(this).marginTop),t=this.getBoundingClientRect(),n=l.getBoundingClientRect(),0<(i=(t.bottom-n.top-n.height+e).toFixed()))&&(l.scrollTop+=Math.min((t.top-n.top-e).toFixed(),i))}function u(e){v(e);e=document.documentElement;e.classList.remove("is-clipped--nav"),a.classList.remove("is-active"),i.classList.remove("is-active"),e.removeEventListener("click",u)}function v(e){e.stopPropagation()}function p(e,t){var n=e.getBoundingClientRect(),i=n.height,a=window.getComputedStyle(c);"sticky"===a.position&&(i-=n.top-parseFloat(a.top)),e.scrollTop=Math.max(0,.5*(t.getBoundingClientRect().height-i)+t.offsetTop)}function m(e,t){return[].slice.call(e.querySelectorAll(t))}l&&(e=i.querySelector("[data-panel=explore]"),c=i.querySelector(".nav"),o=l.querySelector(".is-current-page"),(r=o)?(d(o),p(l,o.querySelector(".nav-link"))):l.scrollTop=0,m(l,".nav-item-toggle").forEach(function(e){var t=e.parentElement,e=(e.addEventListener("click",n.bind(t)),((e,t)=>(!(e=e.nextElementSibling)||!t||e[e.matches?"matches":"msMatchesSelector"](t))&&e)(e,".nav-text"));e&&(e.style.cursor="pointer",e.addEventListener("click",n.bind(t)))}),e&&e.querySelector(".context").addEventListener("click",function(){m(c,"[data-panel]").forEach(function(e){e.classList.toggle("is-active")})}),l.addEventListener("mousedown",function(e){1<e.detail&&e.preventDefault()}),l.querySelector('.nav-link[href^="#"]'))&&(window.location.hash&&t(),window.addEventListener("hashchange",t))})();
(()=>{var e=document.querySelector("aside.toc.sidebar");if(e){if(document.querySelector("body.-toc"))return e.parentNode.removeChild(e);var t=parseInt(e.dataset.levels||2,10);if(!(t<0)){for(var o="article.doc",c=document.querySelector(o),n=[],i=0;i<=t;i++){var a=[o];if(i){for(var r=1;r<=i;r++)a.push((2===r?".sectionbody>":"")+".sect"+r);a.push("h"+(i+1)+"[id]")}else a.push("h1[id].sect0");n.push(a.join(">"))}m=n.join(","),u=c.parentNode;var d,s,l,u,m,f=[].slice.call((u||document).querySelectorAll(m));f.length&&(s={},l=f.reduce(function(e,t){var o=document.createElement("a"),n=(o.textContent=t.textContent,s[o.href="#"+t.id]=o,document.createElement("li"));return n.dataset.level=parseInt(t.nodeName.slice(1),10)-1,n.appendChild(o),e.appendChild(n),e},document.createElement("ul")),(u=e.querySelector(".toc-menu"))||((u=document.createElement("div")).className="toc-menu"),(m=document.createElement("h3")).textContent=e.dataset.title||"On this page",u.appendChild(m),u.appendChild(l),(e=!document.getElementById("toc")&&c.querySelector("h1.page ~ :not(.is-before-toc)"))&&((m=document.createElement("aside")).className="toc embedded",m.appendChild(u.cloneNode(!0)),e.parentNode.insertBefore(m,e)),window.addEventListener("load",function(){p(),window.addEventListener("scroll",p)}))}}function p(){var n,i,t,e=window.pageYOffset,o=1.15*h(document.documentElement,"fontSize")+150,a=c.offsetTop;e&&window.innerHeight+e+2>=document.documentElement.scrollHeight?(d=Array.isArray(d)?d:Array(d||0),n=[],i=f.length-1,f.forEach(function(e,t){var o="#"+e.id;t===i||e.getBoundingClientRect().top+h(e,"paddingTop")>a?(n.push(o),d.indexOf(o)<0&&s[o].classList.add("is-active")):~d.indexOf(o)&&s[d.shift()].classList.remove("is-active")}),n.forEach((e,t)=>{0!==t&&s[e].classList.remove("is-active")}),l.scrollTop=l.scrollHeight-l.offsetHeight,d=1<n.length?n:n[0]):(Array.isArray(d)&&(d.forEach(function(e){s[e].classList.remove("is-active")}),d=void 0),f.some(function(e){if(e.getBoundingClientRect().top+h(e,"paddingTop")-o>a)return!0;t="#"+e.id}),t?t!==d&&(d&&s[d].classList.remove("is-active"),(e=s[t]).classList.add("is-active"),l.scrollHeight>l.offsetHeight&&(l.scrollTop=Math.max(0,e.offsetTop+e.offsetHeight-l.offsetHeight)),d=t):d&&(s[d].classList.remove("is-active"),d=void 0))}function h(e,t){return parseFloat(window.getComputedStyle(e)[t])}})();
(()=>{var o=document.querySelector("article.doc"),t=document.querySelector(".toolbar");function i(e){return e&&(~e.indexOf("%")?decodeURIComponent(e):e).slice(1)}function r(e){if(e){if(e.altKey||e.ctrlKey)return;window.location.hash="#"+this.id,e.preventDefault()}window.scrollTo(0,function e(t,n){return o.contains(t)?e(t.offsetParent,t.offsetTop+n):n}(this,0)-t.getBoundingClientRect().bottom)}window.addEventListener("load",function e(t){var n;(n=i(window.location.hash))&&(n=document.getElementById(n))&&(r.bind(n)(),setTimeout(r.bind(n),0)),window.removeEventListener("load",e)}),Array.prototype.slice.call(document.querySelectorAll('a[href^="#"]')).forEach(function(e){var t;(t=i(e.hash))&&(t=document.getElementById(t))&&e.addEventListener("click",r.bind(t))})})();
(()=>{var t,e=document.querySelector(".page-versions .version-menu-toggle");e&&(t=document.querySelector(".page-versions"),e.addEventListener("click",function(e){t.classList.toggle("is-active"),e.stopPropagation()}),document.documentElement.addEventListener("click",function(){t.classList.remove("is-active")}))})();

(()=>{var o=/^\$ (\S[^\\\n]*(\\\n(?!\$ )[^\\\n]*)*)(?=\n|$)/gm,s=/( ) *\\\n *|\\\n( ?) */g,l=/ +$/gm,d=(document.getElementById("site-script")||{dataset:{}}).dataset;[].slice.call(document.querySelectorAll(".doc pre.highlight, .doc .literalblock pre")).forEach(function(e){var t,a,n,c;if(e.classList.contains("highlight"))(i=(t=e.querySelector("code")).dataset.lang)&&"console"!==i&&((n=document.createElement("span")).className="source-lang",n.appendChild(document.createTextNode(i)));else{if(!e.innerText.startsWith("$ "))return;var i=e.parentNode.parentNode;i.classList.remove("literalblock"),i.classList.add("listingblock"),e.classList.add("highlightjs","highlight"),(t=document.createElement("code")).className="language-console hljs",t.dataset.lang="console",t.appendChild(e.firstChild),e.appendChild(t)}(i=document.createElement("div")).className="source-toolbox",n&&i.appendChild(n),window.navigator.clipboard&&((a=document.createElement("button")).className="copy-button",a.setAttribute("title","Copy to clipboard"),"svg"===d.svgAs?((n=document.createElementNS("http://www.w3.org/2000/svg","svg")).setAttribute("class","copy-icon"),(c=document.createElementNS("http://www.w3.org/2000/svg","use")).setAttribute("href",window.uiRootPath+"/img/octicons-16.svg#icon-clippy"),n.appendChild(c),a.appendChild(n)):((c=document.createElement("img")).src=window.uiRootPath+"/img/octicons-16.svg#view-clippy",c.alt="copy icon",c.className="copy-icon",a.appendChild(c)),(n=document.createElement("span")).className="copy-toast",n.appendChild(document.createTextNode("Copied!")),a.appendChild(n),i.appendChild(a)),e.appendChild(i),a&&a.addEventListener("click",function(e){var t=e.innerText.replace(l,"");"console"===e.dataset.lang&&t.startsWith("$ ")&&(t=(e=>{for(var t,a=[];t=o.exec(e);)a.push(t[1].replace(s,"$1$2"));return a.join(" && ")})(t));window.navigator.clipboard.writeText(t).then(function(){this.classList.add("clicked"),this.offsetHeight,this.classList.remove("clicked")}.bind(this),function(){})}.bind(a,t))})})();
console.log("Chatbot script loaded");let CONFIG={API_URL:"https://backend.agent.starknet.id/api",WS_URL:"wss://backend.agent.starknet.id/ws",MAX_RECONNECT_ATTEMPTS:10,MAX_HISTORY_LENGTH:10,HEARTBEAT_INTERVAL:3e4,RECONNECT_BASE_DELAY:1e3,MAX_RECONNECT_DELAY:3e4,HEARTBEAT_TIMEOUT:5e3},style=document.createElement("style"),chatButton=(style.textContent=`
  #chat-window {
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 400px;
    height: 600px;
    background: #FFFFFF;
    border: 1px solid var(--border);
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: none;
    flex-direction: column;
    z-index: 1000;
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.3s ease, transform 0.3s ease;
  }

  #chat-window.visible {
    opacity: 1;
    transform: translateY(0);
  }

  #chat-header {
    padding: 10px;
    border-bottom: 1px solid var(--border);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .header-left {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  #connection-status {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  #connection-status.connected {
    background-color: #4CAF50;
  }

  #connection-status.disconnected {
    background-color: #f44336;
  }

  .chat-title {
    font-weight: bold;
    font-size: 14px;
  }

  .header-right {
    display: flex;
    gap: 8px;
  }

  .icon-button {
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px;
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .icon-button:hover {
    color: var(--links);
  }

  #chat-messages {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
  }

  .message {
    margin-bottom: 10px;
    padding: 8px 12px;
    border-radius: 8px;
    max-width: 80%;
    font-size: 14px;
    line-height: 1.4;
    width: fit-content;
  }

  .message .content {
    white-space: pre-wrap;
    word-break: break-word;
  }

  .message pre {
    font-size: 13px;
    margin: 8px 0;
    background: rgba(0, 0, 0, 0.05);
    padding: 8px;
    border-radius: 4px;
  }

  .message code {
    font-size: 13px;
    background: rgba(0, 0, 0, 0.05);
    padding: 2px 4px;
    border-radius: 3px;
  }

  .message.user {
    background: #0C0C4F;
    color: #FFFFFF;
    margin-left: auto;
  }

  .message.ai {
    background: #F5F5F5;
    color: #333333;
    margin-right: auto;
    border: 1px solid #E0E0E0;
  }

  .message.loading {
    background: #F5F5F5;
    color: #333333;
    margin-right: auto;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 16px;
    opacity: 0.8;
    width: fit-content;
    border: 1px solid #E0E0E0;
  }

  .loading-dots {
    display: flex;
    gap: 4px;
  }

  .loading-dots span {
    width: 6px;
    height: 6px;
    background: currentColor;
    border-radius: 50%;
    animation: bounce 1.4s infinite ease-in-out both;
  }

  .loading-dots span:nth-child(1) { animation-delay: -0.32s; }
  .loading-dots span:nth-child(2) { animation-delay: -0.16s; }

  @keyframes bounce {
    0%, 80%, 100% { transform: scale(0); }
    40% { transform: scale(1); }
  }

  #chat-input {
    padding: 10px;
    border-top: 1px solid var(--border);
    display: flex;
    gap: 8px;
  }

  #message-input {
    flex: 1;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: 4px;
    background: #F5F5F5;
    color: #666666;
    font-size: 14px;
  }

  #message-input::placeholder {
    color: #999999;
  }

  #chat-toasts {
    position: fixed;
    bottom: 20px;
    left: 20px;
    z-index: 1001;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .chat-toast {
    padding: 10px;
    border-radius: 4px;
    color: #FFFFFF;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    animation: slideIn 0.3s ease-out;
    transition: opacity 0.5s ease;
  }

  .chat-toast.error {
    background: #f44336;
  }

  .chat-toast.warning {
    background: #ff9800;
  }

  @keyframes slideIn {
    from { transform: translateX(-100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`.trim(),document.head.appendChild(style),document.createElement("div")),chatWindow=(chatButton.id="chat-button",chatButton.innerHTML="💬",Object.assign(chatButton.style,{position:"fixed",bottom:"20px",right:"20px",width:"50px",height:"50px",backgroundColor:"#E77787",color:"#FFFFFF",borderRadius:"50%",display:"flex",justifyContent:"center",alignItems:"center",cursor:"pointer",fontSize:"24px",boxShadow:"0 2px 10px rgba(0, 0, 0, 0.2)",zIndex:"1000",transition:"transform 0.3s ease"}),document.body.appendChild(chatButton),document.createElement("div")),breadcrumbContainer=(chatWindow.id="chat-window",chatWindow.innerHTML=`
  <div id="chat-header">
    <div class="header-left">
      <div id="connection-status" class="disconnected" title="Disconnected from server"></div>
      <span class="chat-title">Starknet Assistant</span>
    </div>
    <div class="header-right">
      <button id="clear-history" class="icon-button" title="Clear History">
        <svg viewBox="0 0 24 24" width="16" height="16">
          <path fill="currentColor" d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z" />
        </svg>
      </button>
      <button id="close-chat" class="icon-button" title="Close Chat">
        <svg viewBox="0 0 24 24" width="16" height="16">
          <path fill="currentColor" d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" />
        </svg>
      </button>
    </div>
  </div>
  <div id="chat-messages"></div>
  <div id="chat-input">
    <input type="text" id="message-input" placeholder="Ask anything about Starknet...">
    <button id="send-message" class="icon-button" title="Send Message">
      <svg viewBox="0 0 24 24" width="20" height="20">
        <path fill="currentColor" d="M2,21L23,12L2,3V10L17,12L2,14V21Z" />
      </svg>
    </button>
  </div>
  <div id="chat-toasts"></div>
`.trim(),document.body.appendChild(chatWindow),document.createElement("div"));breadcrumbContainer.id="breadcrumb-container",breadcrumbContainer.style.position="fixed",breadcrumbContainer.style.bottom="20px",breadcrumbContainer.style.left="20px",breadcrumbContainer.style.zIndex="1001",breadcrumbContainer.style.display="flex",breadcrumbContainer.style.flexDirection="column",document.body.appendChild(breadcrumbContainer);class ChatManager{constructor(){this.state={chatSocket:null,chatId:this.generateUniqueId(),reconnectAttempts:0,currentMessageId:null,currentSources:[],currentMessageContent:"",messageHistory:[],isConnecting:!1,lastHeartbeat:null,heartbeatTimeout:null,connectionQuality:"good"},this.initializeDOMElements(),this.attachEventListeners(),this.loadChatHistory(),this.initializeChat()}initializeDOMElements(){this.elements={chatButton:document.getElementById("chat-button"),chatWindow:document.getElementById("chat-window"),messageInput:document.getElementById("message-input"),sendButton:document.getElementById("send-message"),closeButton:document.getElementById("close-chat"),clearButton:document.getElementById("clear-history"),messagesContainer:document.getElementById("chat-messages"),connectionStatus:document.getElementById("connection-status")}}attachEventListeners(){this.elements.chatButton.addEventListener("click",()=>this.toggleChatWindow()),this.elements.closeButton.addEventListener("click",()=>this.closeChatWindow()),this.elements.sendButton.addEventListener("click",()=>this.sendMessage()),this.elements.messageInput.addEventListener("keypress",e=>{"Enter"===e.key&&this.sendMessage()}),this.elements.clearButton.addEventListener("click",()=>this.clearChatHistory())}async initializeChat(){try{await this.fetchModels(),this.connectWebSocket()}catch(e){throw console.error("Error initializing chat:",e),new Error("Failed to initialize chat. Please try again later.")}}async fetchModels(){try{return await(await fetch(CONFIG.API_URL+"/models")).json()}catch(e){throw console.error("Error fetching models:",e),new Error("Failed to fetch models. Please try again later.")}}connectWebSocket(){if(!this.state.isConnecting){var e=new URL(CONFIG.WS_URL);e.search=new URLSearchParams(CONFIG.WS_PARAMS).toString();try{this.state.isConnecting=!0,this.state.chatSocket=new WebSocket(e.toString()),this.setupWebSocketHandlers(),this.setupHeartbeat()}catch(e){console.error("Error creating WebSocket:",e),this.handleWebSocketError(e),this.state.isConnecting=!1}}}setupWebSocketHandlers(){var e=this.state.chatSocket;e.onopen=()=>{console.log("WebSocket connection opened successfully"),this.handleWebSocketOpen(),this.state.isConnecting=!1,this.state.connectionQuality="good",this.state.lastHeartbeat=Date.now()},e.onclose=e=>{console.log("WebSocket connection closed:",{code:e.code,reason:e.reason,wasClean:e.wasClean,timestamp:(new Date).toISOString()}),this.handleWebSocketClose(e),this.state.isConnecting=!1},e.onerror=e=>{console.error("WebSocket error:",e),this.handleWebSocketError(e),this.state.isConnecting=!1},e.onmessage=e=>{try{this.handleWebSocketMessage(e),this.updateConnectionQuality()}catch(e){console.error("Error processing message:",e),this.handleErrorMessage({data:"Error processing message"})}}}setupHeartbeat(){this.heartbeatInterval&&clearInterval(this.heartbeatInterval),this.heartbeatInterval=setInterval(()=>{if(this.state.chatSocket?.readyState===WebSocket.OPEN)try{var e={type:"ping",timestamp:Date.now()};this.state.chatSocket.send(JSON.stringify(e)),this.state.lastHeartbeat=Date.now(),this.state.heartbeatTimeout&&clearTimeout(this.state.heartbeatTimeout),this.state.heartbeatTimeout=setTimeout(()=>{this.handleHeartbeatTimeout()},CONFIG.HEARTBEAT_TIMEOUT)}catch(e){console.error("Error sending heartbeat:",e),this.handleWebSocketError(e)}},CONFIG.HEARTBEAT_INTERVAL)}handleHeartbeatTimeout(){console.warn("Heartbeat timeout - connection might be unstable"),this.state.connectionQuality="poor",this.updateConnectionStatus(),this.state.chatSocket?.readyState===WebSocket.OPEN&&(this.state.chatSocket.close(),this.showBreadcrumbError("Connection timeout - heartbeat failed"))}updateConnectionQuality(){var e;this.state.lastHeartbeat&&((e=Date.now()-this.state.lastHeartbeat)>CONFIG.HEARTBEAT_TIMEOUT?this.state.connectionQuality="poor":e>CONFIG.HEARTBEAT_TIMEOUT/2?this.state.connectionQuality="fair":this.state.connectionQuality="good",this.updateConnectionStatus())}updateConnectionStatus(){var e=this.elements.connectionStatus;if(e)switch(this.state.connectionQuality){case"good":e.className="connected",e.title="Connected to server (Good connection)";break;case"fair":e.className="connected fair",e.title="Connected to server (Fair connection)";break;case"poor":e.className="connected poor",e.title="Connected to server (Poor connection)";break;default:e.className="disconnected",e.title="Disconnected from server"}}handleWebSocketMessage(t){try{let e=JSON.parse(t.data);if(!e||"object"!=typeof e)throw new Error("Invalid message format: message must be an object");if(!e.type)throw new Error("Invalid message format: message must have a type");var s={error:()=>this.handleErrorMessage(e),sources:()=>this.handleSourcesMessage(e),message:()=>this.handleContentMessage(e),messageEnd:()=>this.handleMessageEnd(),pong:()=>{this.state.lastHeartbeat=Date.now(),this.updateConnectionQuality()}}[e.type];s?s():console.warn("Unknown message type:",e.type)}catch(e){console.error("Error processing WebSocket message:",e),this.handleErrorMessage({data:"Error processing message"})}}handleErrorMessage(e){throw console.error("Received error message:",e.data),this.removeLoadingIndicator(),new Error(e.data)}handleSourcesMessage(e){this.state.currentSources=e.data,this.state.currentMessageId=e.messageId}handleContentMessage(e){this.state.currentMessageId!==e.messageId&&(this.state.currentMessageId=e.messageId,this.state.currentMessageContent="",this.appendStreamingMessage(this.state.currentMessageId)),this.state.currentMessageContent+=e.data,this.updateStreamingMessage(this.state.currentMessageId,this.state.currentMessageContent,this.state.currentSources)}handleMessageEnd(){this.removeLoadingIndicator(),this.updateStreamingMessage(this.state.currentMessageId,this.state.currentMessageContent,this.state.currentSources),this.state.messageHistory.push(["ai",this.state.currentMessageContent]),this.trimMessageHistory(),this.saveChatHistory(),this.resetCurrentMessageState()}sendMessage(){var e=this.elements.messageInput.value.trim();if(e){if(this.state.chatSocket?.readyState!==WebSocket.OPEN)throw new Error("Not connected to the chat server. Please try again later.");this.elements.messageInput.value="",this.sendMessageToServer(e),this.showLoadingIndicator()}}sendMessageToServer(e){var t=this.generateUniqueId(),s={type:"message",message:{messageId:t,chatId:this.state.chatId,content:e},copilot:!1,focusMode:"starknetEcosystemSearch",history:this.state.messageHistory};this.state.chatSocket.send(JSON.stringify(s)),this.state.messageHistory.push(["human",e]),this.trimMessageHistory(),this.appendMessage("user",e,t)}saveChatHistory(){localStorage.setItem("chatHistory",JSON.stringify(this.state.messageHistory)),localStorage.setItem("chatId",this.state.chatId)}loadChatHistory(){var e=localStorage.getItem("chatHistory"),t=localStorage.getItem("chatId");e&&(this.state.messageHistory=JSON.parse(e),this.state.chatId=t||this.generateUniqueId(),this.elements.messagesContainer.innerHTML="",this.state.messageHistory.forEach(([e,t])=>{this.appendMessage("human"===e?"user":"ai",t)}))}generateUniqueId(){return""+Date.now().toString(36)+Math.random().toString(36).substr(2)}trimMessageHistory(){this.state.messageHistory.length>CONFIG.MAX_HISTORY_LENGTH&&(this.state.messageHistory=this.state.messageHistory.slice(-CONFIG.MAX_HISTORY_LENGTH))}resetCurrentMessageState(){this.state.currentSources=[],this.state.currentMessageId=null,this.state.currentMessageContent=""}showLoadingIndicator(){var e=document.createElement("div");e.className="message loading",e.innerHTML=`
      Thinking
      <div class="loading-dots">
        <span></span><span></span><span></span>
      </div>
    `,this.elements.messagesContainer.appendChild(e),this.scrollToBottom()}removeLoadingIndicator(){var e=document.querySelector(".message.loading");e&&e.remove()}scrollToBottom(){this.elements.messagesContainer.scrollTop=this.elements.messagesContainer.scrollHeight}toggleChatWindow(){var e="flex"===this.elements.chatWindow.style.display;e?(this.elements.chatWindow.classList.remove("visible"),this.elements.chatButton.innerHTML="💬",setTimeout(()=>{this.elements.chatWindow.style.display="none"},300)):(this.elements.chatWindow.style.display="flex",this.elements.chatWindow.classList.add("visible"),this.elements.chatButton.innerHTML="❌"),document.body.classList.toggle("chat-open",!e)}closeChatWindow(){this.elements.chatWindow.classList.remove("visible"),this.elements.chatButton.innerHTML="💬",setTimeout(()=>{this.elements.chatWindow.style.display="none",document.body.classList.remove("chat-open"),this.saveChatHistory()},300)}appendMessage(e,t,s=null){var a=document.createElement("div"),e=(a.className="message "+e,s&&(a.id="message-"+s),document.createElement("div"));e.className="content",e.innerHTML=this.processMarkdown(t),a.appendChild(e),this.elements.messagesContainer.appendChild(a),this.scrollToBottom(),this.saveChatHistory()}appendStreamingMessage(e){var t=document.createElement("div"),e=(t.className="message ai streaming",t.id="message-"+e,document.createElement("div"));return e.className="content",t.appendChild(e),this.elements.messagesContainer.appendChild(t),this.scrollToBottom(),t}updateStreamingMessage(e,t,s){let a=document.getElementById("message-"+e);e=(a=a||this.appendStreamingMessage(e)).querySelector(".content");e&&(t=this.processMarkdown(t,s),e.innerHTML=t,this.highlightCodeBlocks(),this.scrollToBottom())}highlightCodeBlocks(){window.Prism&&Prism.highlightAll()}processMarkdown(e,a=[]){let t=e.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>").replace(/\[(\d+)\]/g,(e,t)=>{var s=parseInt(t)-1;return a[s]?.metadata?.url?`<a href="${a[s].metadata.url}" target="_blank">[${t}]</a>`:e});return t=t.replace(/```(\w+)?\n([\s\S]*?)```/g,(e,t,s)=>`<pre><code class="language-${t||"plaintext"}">${this.escapeHtml(s.trim())}</code></pre>`),0<a.length&&(e=a.map((e,t)=>`[${t+1}] <a href="${e.metadata.url}" target="_blank">${e.metadata.title||"Untitled"}</a>`).join("\n"),t+=`

Relevant pages:
`+e),t}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}handleWebSocketOpen(){console.log("WebSocket connection opened"),this.setWSReady(!0),this.state.reconnectAttempts=0,this.setupHeartbeat()}handleWebSocketClose(e){console.log("WebSocket connection closed:",e),this.setWSReady(!1),this.heartbeatInterval&&clearInterval(this.heartbeatInterval),this.state.heartbeatTimeout&&clearTimeout(this.state.heartbeatTimeout),1e3!==e.code&&1001!==e.code&&this.attemptReconnect()}handleWebSocketError(e){console.error("WebSocket error:",e),this.state.chatSocket?.readyState===WebSocket.OPEN&&this.state.chatSocket.close(),this.showBreadcrumbError("WebSocket connection error occurred")}setWSReady(e){this.elements.connectionStatus.className=e?"connected":"disconnected",this.elements.connectionStatus.title=e?"Connected to server":"Disconnected from server"}attemptReconnect(){var e;this.state.reconnectAttempts++,this.state.reconnectAttempts<=CONFIG.MAX_RECONNECT_ATTEMPTS?(e=Math.min(CONFIG.RECONNECT_BASE_DELAY*Math.pow(2,this.state.reconnectAttempts-1),CONFIG.MAX_RECONNECT_DELAY)+1e3*Math.random(),console.log(`Reconnect attempt ${this.state.reconnectAttempts} in ${Math.round(e)}ms`),this.showBreadcrumbError(`Connection lost. Attempting to reconnect (${this.state.reconnectAttempts}/${CONFIG.MAX_RECONNECT_ATTEMPTS})...`),setTimeout(()=>this.connectWebSocket(),e)):(console.error("Max reconnection attempts reached"),this.showBreadcrumbError("Failed to connect after multiple attempts. Please refresh the page."))}clearChatHistory(){this.state.messageHistory=[],this.elements.messagesContainer.innerHTML="",this.state.chatId=this.generateUniqueId()}showToast(t,s){var a=document.getElementById("chat-toasts");if(a){let e=document.createElement("div");e.className="chat-toast "+s,e.textContent=t,a.appendChild(e),setTimeout(()=>{e.style.opacity="0",setTimeout(()=>{e.remove()},500)},3e3)}}showBreadcrumbError(e){let t=document.createElement("div");t.className="breadcrumb-error",t.textContent=e,t.style.backgroundColor="#f44336",t.style.color="#FFFFFF",t.style.padding="10px",t.style.borderRadius="4px",t.style.marginBottom="5px",t.style.transition="opacity 0.5s ease",breadcrumbContainer.appendChild(t),setTimeout(()=>{t.style.opacity="0",setTimeout(()=>{t.remove()},500)},3e3)}}document.addEventListener("DOMContentLoaded",()=>{window.chatManager=new ChatManager}),window.addEventListener("beforeunload",()=>{window.chatManager&&window.chatManager.saveChatHistory()});
//# sourceMappingURL=site.js.map